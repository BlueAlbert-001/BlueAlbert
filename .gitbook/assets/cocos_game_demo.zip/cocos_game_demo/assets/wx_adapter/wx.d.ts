/**
 * @description 微信全局对象类型声明
 * @author derick
 */
const wx:any;
const GameGlobal:any;
const canvas:any;